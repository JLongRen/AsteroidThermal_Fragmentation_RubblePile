function X=LdeL1(a,b,c)
X=10^((b-a)*c+a);

end